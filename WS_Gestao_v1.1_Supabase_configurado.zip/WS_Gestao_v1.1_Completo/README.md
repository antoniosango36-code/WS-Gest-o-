# WS Gestão v1.1 — Comercial

Aplicativo Android-first para gestão de pequenos negócios em Angola.

## Incluído
- Login/cadastro real via Supabase Auth
- Empresa criada automaticamente para o utilizador
- Dashboard com vendas, despesas, lucro e stock baixo
- Produtos e stock
- Clientes e saldo de fiado
- Vendas com dinheiro, transferência, Multicaixa Express e fiado
- Baixa automática de stock
- Atualização automática da dívida no fiado
- Finanças e despesas
- RLS no banco de dados
- RPC transacional para evitar vendas com stock insuficiente
- Moeda AOA/Kz

## Configuração
1. Criar projeto no Supabase.
2. Executar `supabase/schema.sql` no SQL Editor.
3. Obter Project URL e anon key.
4. Executar:

`flutter pub get`

`flutter run --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_ANON`

Para APK:

`flutter build apk --release --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_ANON`

Para Play Store (AAB):

`flutter build appbundle --release --dart-define=SUPABASE_URL=https://SEU-PROJETO.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_ANON`

## Estado
O código e o esquema estão preparados para a fase de integração. Este ambiente não tem Flutter instalado e não possui as credenciais do projeto Supabase do proprietário; por isso não é possível gerar aqui um APK assinado ou afirmar que foi publicado na Play Store.

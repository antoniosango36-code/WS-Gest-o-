# WS Gestão — configuração e APK

O projeto já está apontado para:
`https://dtnhskdjgkuorixjlty.supabase.co`

A chave publicável não foi incluída neste pacote por segurança.

## Gerar APK
Com Flutter instalado, na pasta do projeto:

```bash
flutter pub get
flutter build apk --release --dart-define=SUPABASE_URL=https://dtnhskdjgkuorixjlty.supabase.co --dart-define=SUPABASE_ANON_KEY=SUA_CHAVE_PUBLICAVEL
```

APK: `build/app/outputs/flutter-apk/app-release.apk`

Nunca coloque uma `service_role`/chave secreta no aplicativo.


-- WS Gestão - estrutura inicial Supabase/PostgreSQL
create extension if not exists pgcrypto;

create table if not exists businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  nif text,
  phone text,
  province text,
  address text,
  business_type text,
  currency text not null default 'AOA',
  created_at timestamptz not null default now()
);

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  name text not null,
  purchase_price numeric(14,2) not null default 0,
  sale_price numeric(14,2) not null default 0,
  stock integer not null default 0,
  minimum_stock integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  name text not null,
  phone text,
  address text,
  notes text,
  debt numeric(14,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists sales (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  customer_id uuid references customers(id) on delete set null,
  total numeric(14,2) not null default 0,
  payment_method text not null default 'cash',
  created_at timestamptz not null default now()
);

create table if not exists sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references sales(id) on delete cascade,
  product_id uuid not null references products(id),
  quantity integer not null check(quantity > 0),
  unit_price numeric(14,2) not null default 0,
  subtotal numeric(14,2) not null default 0
);

create table if not exists expenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  category text not null,
  amount numeric(14,2) not null default 0,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists customer_payments (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references customers(id) on delete cascade,
  amount numeric(14,2) not null check(amount > 0),
  note text,
  created_at timestamptz not null default now()
);

-- Segurança: cada utilizador só deve consultar dados das empresas de que é proprietário.
alter table businesses enable row level security;
alter table products enable row level security;
alter table customers enable row level security;
alter table sales enable row level security;
alter table sale_items enable row level security;
alter table expenses enable row level security;
alter table customer_payments enable row level security;

create policy "owner businesses" on businesses
for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

create policy "owner products" on products
for all using (exists (
  select 1 from businesses b where b.id=products.business_id and b.owner_id=auth.uid()
)) with check (exists (
  select 1 from businesses b where b.id=products.business_id and b.owner_id=auth.uid()
));

create policy "owner customers" on customers
for all using (exists (
  select 1 from businesses b where b.id=customers.business_id and b.owner_id=auth.uid()
)) with check (exists (
  select 1 from businesses b where b.id=customers.business_id and b.owner_id=auth.uid()
));

create policy "owner sales" on sales
for all using (exists (
  select 1 from businesses b where b.id=sales.business_id and b.owner_id=auth.uid()
)) with check (exists (
  select 1 from businesses b where b.id=sales.business_id and b.owner_id=auth.uid()
));

create policy "owner expenses" on expenses
for all using (exists (
  select 1 from businesses b where b.id=expenses.business_id and b.owner_id=auth.uid()
)) with check (exists (
  select 1 from businesses b where b.id=expenses.business_id and b.owner_id=auth.uid()
));

create policy "owner sale items" on sale_items
for all using (exists (
  select 1 from sales s join businesses b on b.id=s.business_id
  where s.id=sale_items.sale_id and b.owner_id=auth.uid()
)) with check (exists (
  select 1 from sales s join businesses b on b.id=s.business_id
  where s.id=sale_items.sale_id and b.owner_id=auth.uid()
));

create policy "owner payments" on customer_payments
for all using (exists (
  select 1 from customers c join businesses b on b.id=c.business_id
  where c.id=customer_payments.customer_id and b.owner_id=auth.uid()
)) with check (exists (
  select 1 from customers c join businesses b on b.id=c.business_id
  where c.id=customer_payments.customer_id and b.owner_id=auth.uid()
));

-- RPC transacional para registar venda, baixar stock e lançar fiado com segurança.
create or replace function create_sale(
  p_business_id uuid,
  p_customer_id uuid,
  p_payment_method text,
  p_items jsonb
) returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_sale_id uuid;
  v_total numeric(14,2) := 0;
  v_item jsonb;
  v_product products%rowtype;
  v_qty integer;
  v_sub numeric(14,2);
begin
  if not exists (select 1 from businesses where id=p_business_id and owner_id=auth.uid()) then
    raise exception 'Empresa não autorizada';
  end if;
  if p_payment_method='credit' and (p_customer_id is null or not exists(select 1 from customers where id=p_customer_id and business_id=p_business_id)) then
    raise exception 'Cliente inválido para fiado';
  end if;
  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    select * into v_product from products where id=(v_item->>'product_id')::uuid and business_id=p_business_id for update;
    if not found then raise exception 'Produto não encontrado'; end if;
    if v_qty <= 0 or v_product.stock < v_qty then raise exception 'Stock insuficiente para %', v_product.name; end if;
    v_total := v_total + v_product.sale_price * v_qty;
  end loop;
  insert into sales(business_id,customer_id,total,payment_method) values(p_business_id,p_customer_id,v_total,p_payment_method) returning id into v_sale_id;
  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    select * into v_product from products where id=(v_item->>'product_id')::uuid and business_id=p_business_id for update;
    v_sub := v_product.sale_price * v_qty;
    insert into sale_items(sale_id,product_id,quantity,unit_price,subtotal) values(v_sale_id,v_product.id,v_qty,v_product.sale_price,v_sub);
    update products set stock=stock-v_qty where id=v_product.id;
  end loop;
  if p_payment_method='credit' then
    update customers set debt=debt+v_total where id=p_customer_id;
  end if;
  return v_sale_id;
end;
$$;

grant execute on function create_sale(uuid,uuid,text,jsonb) to authenticated;
